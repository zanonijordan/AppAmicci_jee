/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.mws2018039.amici.exception;

/**
 *
 * @author er
 */
public class AppAmiciException extends Exception {

    public AppAmiciException(String msg) {
        super(msg);
    }
    
}
